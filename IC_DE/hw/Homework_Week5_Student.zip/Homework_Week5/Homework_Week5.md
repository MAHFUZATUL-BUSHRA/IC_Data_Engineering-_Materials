# Homework — Week 5: SQL Fundamentals

**Course:** Modern Data Engineering — Depthware
**Covers:** Sessions 9 & 10 (SQL Core Concepts + Advanced SQL)
**Total marks:** 100
**Format:** Jupyter notebook (`.ipynb`) submission

---

## Overview

This homework brings together everything from Week 5 — single-table queries with
`SELECT`/`WHERE`/`GROUP BY`/`HAVING` from Session 9, and `JOIN`s, `CTE`s, and
window functions from Session 10. Every question uses the **same ride-hailing
dataset you've already been working with** (the four CSVs in `data/`). No new
schema to learn — just SQL.

A template notebook has been provided: `Homework_Week5_Template.ipynb`. Open it,
fill in the empty code cell beneath each question with your `q("""...""")` call,
run it to confirm your output, and submit the completed notebook.

---

## Setup

1. Place the four CSVs (`cities.csv`, `drivers.csv`, `riders.csv`, `rides.csv`)
   in a `data/` folder beside `Homework_Week5_Template.ipynb`.
2. Activate the same virtual environment you used for Sessions 9 and 10
   (DuckDB + pandas + jupyterlab).
3. Launch JupyterLab **from this folder** so the relative paths resolve.

The first cell of the template loads all four tables and defines the `q()`
helper — just run it. If you see `IO Error: No files found...`, you've
launched Jupyter from the wrong folder. (Same fix as the lesson SETUP guides.)

---

## Marks distribution

| Section | Topic | Marks |
|---|---|---|
| **A** | Session 9 — single-table queries | **30** |
| **B** | Session 10 — JOINs & CTEs | **35** |
| **C** | Session 10 — Window functions | **25** |
| **D** | Capstone — combining everything | **10** |
| **Bonus** | Engagement & code quality (see rubric) | **+5** |

---

## Section A — Session 9 foundations (30 marks)

### Q1 (5 marks) — `SELECT` + `WHERE` + `ORDER BY`

List the `ride_id`, `distance_km`, and `fare` of all **completed** rides that
are **between 25 and 30 km** (inclusive). Order by fare descending. Show the
top 5.

### Q2 (5 marks) — `IS NULL`

Some rides have a missing `driver_id` (these are cancelled rides where no
driver was assigned). Write **two separate queries**:

- **(a)** Count how many rides have a missing `driver_id`.
- **(b)** List **any 3** such rides showing `ride_id`, `rider_id`, and `status`.

### Q3 (10 marks) — Aggregates with `NULL` handling

In **one query**, compute these metrics over the **entire rides table** (do
NOT filter — we want to see how aggregates behave with `NULL`s):

- `total_rides` — total number of rides
- `rides_with_fare` — number of rides that have a non-null fare
- `revenue` — total fare summed, rounded to the nearest whole number
- `avg_fare` — average fare, rounded to 2 decimal places
- `max_fare` and `min_fare`

Then, in a **short markdown cell**, briefly explain why `total_rides` and
`rides_with_fare` differ.

### Q4 (5 marks) — `GROUP BY` + `HAVING`

For **completed rides only**, group rides by `ride_date` and show the date,
its ride count, and its revenue (rounded). Show **only days with more than
17 rides**, ordered by ride count descending.

### Q5 (5 marks) — Conceptual: `WHERE` vs `HAVING`

A student writes the query below to find drivers with more than 20 completed
rides — and gets an error.

```sql
SELECT driver_id, COUNT(*) AS rides
FROM rides
WHERE status = 'completed'
  AND COUNT(*) > 20
GROUP BY driver_id
```

In a **markdown cell**, explain in 1–2 sentences why this fails. Then, in a
code cell, provide a **corrected version** that returns the same intent.

---

## Section B — JOINs & CTEs (35 marks)

### Q6 (10 marks) — `INNER JOIN` + `GROUP BY`

List the **top 10 drivers by total revenue** from completed rides. Show
`driver_id`, name, vehicle type, ride count, and total revenue (rounded).
Order by revenue descending.

> **Hint:** Include `driver_id` in your `GROUP BY`. Two different drivers can
> share the same name in this dataset — grouping by name alone will silently
> merge them and give wrong totals.

### Q7 (10 marks) — `LEFT JOIN`

For each of the 5 cities, show two counts:

- `riders` — number of riders based in that city
- `completed_rides` — number of completed rides taken by those riders

**Use a `LEFT JOIN`** so that all 5 cities are guaranteed to appear in your
output, even if one had zero. Order by `completed_rides` descending.

### Q8 (15 marks) — CTE chain

Using a **CTE** (`WITH ... AS`), do this in two steps:

1. First, build a per-driver summary of **completed rides only**: ride count
   (`rides`), total revenue (`revenue`), and average fare per ride (`avg_fare`).
2. Then, from that summary, return only drivers whose **average fare per ride
   exceeds 250 TRY**.

Show `driver_id`, `rides`, `revenue` (rounded to 0 decimals), and `avg_fare`
(rounded to 2 decimals). Order by `avg_fare` descending.

---

## Section C — Window functions (25 marks)

### Q9 (10 marks) — Ranking comparison

Using a CTE, compute total revenue per driver (completed rides only). Then add
**three ranking columns** to that summary, all ordered by revenue descending:

- `row_number` — using `ROW_NUMBER()`
- `rank_` — using `RANK()`
- `dense_rank_` — using `DENSE_RANK()`

> **Note:** `rank` is a reserved word in some SQL dialects, which is why we
> use `rank_` (and `dense_rank_` for consistency).

Show the top 10 rows. Then, in a **markdown cell**, briefly explain (1 sentence
each) when the three ranking functions would produce **different** values from
each other. (They won't differ in *this* output because revenues are all
distinct — answer the question conceptually.)

### Q10 (15 marks) — Group total vs running total

Pick **driver_id 14** — the second-highest earner. List every completed ride
for that driver in date order, showing four columns:

- `ride_date`
- `fare`
- `driver_total` — driver 14's grand total revenue, **stamped on every row**
  (use `SUM(fare) OVER (PARTITION BY driver_id)`)
- `running_total` — cumulative fare up to and including this ride
  (use `SUM(fare) OVER (PARTITION BY driver_id ORDER BY ride_date, ride_id)`)

Round both columns to 0 decimals.

In a **markdown cell**, write 1–2 sentences explaining what makes
`driver_total` and `running_total` behave differently — even though both use
`SUM(fare)` over the same partition.

---

## Section D — Capstone (10 marks)

### Q11 (10 marks) — Top earner per city

In a **single query**, using CTEs, multiple joins, and a window function,
produce this analysis:

> *For each city, find its **top-earning driver** — the driver who earned the
> most revenue from completed rides taken by riders based in that city.*

Output: `city_name`, `driver` (name), `vehicle_type`, `revenue` (rounded).
Order by revenue descending.

**Hint:** Three joins are needed — `rides` → `drivers` (to get the driver's
name), `rides` → `riders` → `cities` (to get the rider's city). Aggregate per
`(city, driver)`, then use `RANK() OVER (PARTITION BY city ...)` to find #1
per city.

---

## Grading rubric

Each question is graded on:

| Criterion | Weight |
|---|---|
| **Correctness** — does the query return the right answer? | 60% |
| **Task completion** — does it follow the spec (columns, ordering, filters, rounding)? | 25% |
| **Code quality** — readable formatting, sensible aliases, no dead code | 15% |

**Bonus (+5)** is awarded across the assignment for:

- Particularly clean, well-commented queries
- Explanations that show genuine understanding (not just restating definitions)
- Catching and discussing subtle issues (e.g., the duplicate-names trap in Q6)
- Trying alternative approaches and explaining the trade-offs

**Important:** All queries must be your own work. Discussing concepts with
classmates is fine; sharing actual SQL is not.

---

## Submission

- Save your completed notebook as `Homework_Week5_<YourName>.ipynb`.
- Make sure **every code cell has been run** so outputs are visible.
- Submit via the course portal by the deadline announced in class.

---

*Depthware · Modern Data Engineering · Week 5 Homework*
